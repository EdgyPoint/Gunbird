# Gunbird

This is a tribute to Gunbird, an arcade game developed by Psikyo. This project is used for the subject Project 1 in Game Development and Design in the CITM, from the Politecnical University of Catalonia.

For information about the game, check the wiki on this repository: https://github.com/EdgyPoint/Project-1/wiki.

## Installation

Unzip the folder in whatever directory you prefer.

## Usage

Execute "Gunbird.exe".

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## History

TODO: Write history

## Credits

Psikyo
Edgypoint
Ratkid Studio
Watermelon $quad
Coded Dreams
Frozensloth Studios

## License

We don't own any rights over Gunbird and its intellectual properties. The credit for the game goes entirely to Psikyo, currently property of X-Nauts. 
